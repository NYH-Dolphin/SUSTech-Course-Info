if b'':
    print('123')