import mimetypes
import asyncio
import os
import time
from urllib.parse import unquote
import argparse

'''
ERROR message format_404 & 405
Head message format_200
'''
err405 = [b'HTTP/1.0 405 Method Not Allowed\r\n',
          b'Content-Type:text/html; charset=utf-8\r\n',
          b'Connection: close\r\n',
          b'\r\n',
          b'<html><body>405 Method Not Allowed</body></html>\r\n',
          b'\r\n']

err404 = [b'HTTP/1.0 404 Not Found\r\n',
          b'Content-Type:text/html; charset=utf-8\r\n',
          b'Connection: close\r\n',
          b'\r\n',
          b'<html><body>404 Not Found</body></html>\r\n',
          b'\r\n']

head200 = [b'HTTP/1.0 200 OK\r\n',
           b'Content-Type:text/html; charset=utf-8\r\n',
           b'Connection: close',
           b'\r\n']

'''
The following Method are used to create ordered HTML format
'''


def GETfile(file, filetype, path):
    returnfile = [
        b'HTTP/1.0 200 OK\r\n',
        b'Content-Type:',
        str.encode(filetype),
        b'\r\n',
        b'Content-Length:',
        str.encode(str(os.path.getsize(path))),
        b'\r\n',
        b'Connection: close\r\n',
        b'\r\n',
        file.read(),
        b'\r\n'
    ]
    return returnfile


def GETdirectory(message):
    returnfile = [
        b'HTTP/1.0 200 OK\r\n',
        b'Content-Type:text/html; charset=utf-8\r\n',
        b'Connection: close\r\n',
        b'\r\n'
        b'<html>',
        str.encode(message),
        b'</html>\r\n',
        b'\r\n'
    ]
    return returnfile


def HEADfile(path, filetype):
    returnfile = [
        b'HTTP/1.0 200 OK\r\n',
        b'Content-Type:t\r\n',
        str.encode(filetype),
        b'; charset=utf-8\r\n',
        b'Content-Length:',
        str.encode(str(os.path.getsize(path))),
        b'\r\n',
        b'Connection: close\r\n',
        b'\r\n'
    ]
    return returnfile


'''
Create HTTP Header
'''


def createHTML(path, current_path):
    html = ''
    html += '<head><title>' + 'Index of ' + path + '</title></head>'
    html += '<body bgcolor = "white">'
    html += '<h1>' + 'Index of ' + path + '</h1>'
    html += '<pre>'

    html += '<a href=\"' + current_path + '..' + '/\">' + '../' + '</a><br>'
    list = os.listdir(path)
    for element in list:
        if os.path.isdir(path + element):
            html += '<a href=\"' + current_path + element + '/\">' + element + '/</a><br>'
        else:
            html += '<a href=\"' + current_path + element + '\">' + element + '</a><br>'
    html += '</pre>'
    html += '</body>'

    return html


class createHEMLheader:
    def __init__(self):
        self.headers = {'method': '', 'path': ''}

    def parse_header(self, line):
        fileds = unquote(line, encoding='utf-8').split(' ')
        if str.upper(fileds[0]) == 'GET' or str.upper(fileds[0]) == 'HEAD':
            self.headers['method'] = str.upper(fileds[0])
            path = fileds[1]
            if (len(fileds) > 3):
                for i in range(2, len(fileds) - 1):
                    path += ' ' + fileds[i]
            self.headers['path'] = path

    def get(self, key):
        return self.headers.get(key)


async def dispatch(reader, writer):
    # Get HTTP header
    header = createHEMLheader()

    # Receive Request ing~~
    while True:
        data = await reader.readline()
        message = data.decode()
        header.parse_header(message)
        if data == b'\r\n':
            break

    # GET method
    if header.get('method') == 'GET':

        # Create Path
        path = args.dir + header.get('path')

        # Path exists
        if os.path.exists(path):

            # The path is a Directory
            if os.path.isdir(path):

                message = createHTML(path, header.get('path'))
                writer.writelines(GETdirectory(message))

            # The path is a File
            else:
                # Use MIME to guess file type
                file = open(path, 'rb')
                filetype = mimetypes.guess_type(header.get('path'))[0]
                # Can not figure out file type
                if filetype is None:
                    filetype = 'application/octet-stream'
                writer.writelines(GETfile(file, filetype, path))

        # Path not exist
        else:
            writer.writelines(err404)


    # HEAD meathod
    elif header.get('method') == 'HEAD':

        # Create Path
        path = args.dir + header.get('path')

        # Path exists
        if os.path.exists(path):

            # Path is directory
            if os.path.isdir(path):
                writer.writelines(head200)

            # Path is file
            else:
                # Use MIME to guess file type
                filetype = mimetypes.guess_type(header.get('path'))[0]

                # Can not figure out file type
                if filetype is None:
                    filetype = 'application/octet-stream'

                writer.writelines(HEADfile(path, filetype))

    # POST method
    elif header.get('method') == 'POST':

        # Concurrent test
        time.sleep(2)
        writer.writelines([err405])

    # NOT SUPPORT method
    else:
        writer.writelines([err405])

    await writer.drain()
    writer.close()


if __name__ == '__main__':

    # Set Up Basic Argument
    parser = argparse.ArgumentParser(description='Simple Web File Browser')
    parser.add_argument('--port', type=int, default=8080,
                        help='an integer for the port of the simple web file browser')
    parser.add_argument('--dir', type=str, default="./",
                        help='The Directory that the browser should display for home page')
    args = parser.parse_args()
    ip = '127.0.0.1'
    print("server run at port %d" % args.port)
    print("server run at dir %s" % args.dir)

    # Create Asyncio Server
    loop = asyncio.get_event_loop()
    coro = asyncio.start_server(dispatch, ip, args.port, loop=loop)
    server = loop.run_until_complete(coro)

    # Serve requests until Ctrl+C is pressed
    try:
        loop.run_forever()
    except KeyboardInterrupt:
        pass

    # Close the server
    server.close()
    loop.run_until_complete(server.wait_closed())
    loop.close()
