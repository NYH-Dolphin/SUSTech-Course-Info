drop table students;

create table students
(
 id serial primary key,
 studentid varchar(8),
 name varchar
);
