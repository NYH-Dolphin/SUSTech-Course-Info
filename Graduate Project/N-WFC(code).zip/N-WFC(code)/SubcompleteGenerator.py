import random

import Tools
import numpy as np
from PIL import Image


def sub_complete_generator(E_NS, E_WE):
    comb_NS = list()
    for e1 in E_NS:
        for e2 in E_NS:
            comb_NS.append((e1, e2))
    comb_WE = list()
    for e1 in E_WE:
        for e2 in E_WE:
            comb_WE.append((e1, e2))
    comb_NW = list()
    for e1 in E_NS:
        for e2 in E_WE:
            comb_NW.append((e1, e2))
    comb_SE = list()
    for e1 in E_NS:
        for e2 in E_WE:
            comb_SE.append((e1, e2))

    max_comb = comb_NS if len(comb_NS) >= len(comb_WE) else comb_WE
    min_comb = comb_NS if len(comb_NS) < len(comb_WE) else comb_WE
    appear_tile = set()
    tileset = list()
    for i in range(len(max_comb)):
        j = i
        while j >= len(min_comb):
            j -= len(min_comb)
        comb1 = max_comb[i]
        comb2 = min_comb[j]
        if max_comb == comb_NS:
            tileset.append(np.array([comb1[0], comb1[1], comb2[0], comb2[1]], dtype=int))
        else:
            tileset.append(np.array([comb2[0], comb2[1], comb1[0], comb1[1]], dtype=int))
        appear_tile.add(str(tileset[i]))

    for (e_n, e_w) in comb_NW:
        e_s = random.choice(E_NS)
        e_e = random.choice(E_WE)
        tile = np.array([e_n, e_s, e_w, e_e], dtype=int)
        if str(tile) not in appear_tile:
            tileset.append(tile)
            appear_tile.add(str(tile))
    for (e_s, e_e) in comb_SE:
        e_n = random.choice(E_NS)
        e_w = random.choice(E_WE)
        tile = np.array([e_n, e_s, e_w, e_e], dtype=int)
        if str(tile) not in appear_tile:
            tileset.append(tile)
            appear_tile.add(str(tile))

    state_dictionary = np.array(tileset).T  # convert the tileset to state_dictionary format
    return state_dictionary


def save_state_dictionary(tileset_name, state_dictionary):
    Tools.create_folder(tileset_name)
    Tools.create_folder(tileset_name + '/' + 'SimpleTiled')
    np.savetxt(tileset_name + '/' + 'SimpleTiled/' + 'state_dictionary.csv', state_dictionary, delimiter=",", fmt='%i')
    for i in range(len(state_dictionary[0])):
        tile_img = Image.new('RGB', (10, 10))
        tile_img.save(tileset_name + '/' + 'SimpleTiled/' + '{}.png'.format(i))


if __name__ == '__main__':
    E_NS = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    E_WE = [2, 3, 4, 5, 6, 7, 8, 9, 10]
    state_dictionary = sub_complete_generator(E_NS, E_WE)
    save_state_dictionary('SubComplete-9-9', state_dictionary)
