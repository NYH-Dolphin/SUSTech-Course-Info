from WFC import WFC
from NWFC import NWFC
import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot


def plot_experiment_result(title, wfc, nwfc):
    plt.style.use('seaborn-whitegrid')
    palette = pyplot.get_cmap('Set1')
    font1 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 18,
             }
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(1, 1, 1)
    iters = ['(5×9)', '(9×17)', '(17×33)', '(25×49)', '(33×75)', '(41×81)', '(49×97)']

    (wfc_mean, wfc_std) = wfc
    (nwfc_mean, nwfc_std) = nwfc

    color = palette(0)
    r1 = [wfc_mean[i] + wfc_std[i] for i in range(len(wfc_mean))]
    r2 = [wfc_mean[i] - wfc_std[i] for i in range(len(wfc_mean))]
    ax.plot(iters, wfc_mean, color=color, label="wfc", linewidth=3.0)
    ax.fill_between(iters, r1, r2, color=color, alpha=0.2)

    color = palette(1)
    r1 = [nwfc_mean[i] + nwfc_std[i] for i in range(len(nwfc_mean))]
    r2 = [nwfc_mean[i] - nwfc_std[i] for i in range(len(nwfc_mean))]
    ax.plot(iters, nwfc_mean, color=color, label="n-wfc", linewidth=3.0)
    ax.fill_between(iters, r1, r2, color=color, alpha=0.2)

    ax.legend(loc='lower right', prop=font1)
    ax.set_xlabel('Board Size (height × width)', fontsize=15)
    ax.set_ylabel('Time Cost (per second)', fontsize=15)
    plt.title(title, fontsize=30)
    plt.show()


if __name__ == '__main__':
    nwfc = NWFC('SubComplete-9-9/SimpleTiled/', 'SubComplete-9-9/NWFCResult/')
    wfc = WFC('SubComplete-9-9/SimpleTiled/', 'SubComplete-9-9/WFCResult/', simple_tiled=True)
    wfc_list = [(5, 9), (9, 17), (17, 33), (25, 49), (33, 75), (41, 81), (49, 97)]
    nwfc_list = [(1, 2), (2, 4), (4, 8), (6, 12), (8, 16), (10, 20), (12, 24)]

    wfc_mean = list()
    wfc_std = list()
    nwfc_mean = list()
    nwfc_std = list()

    for a in range(7):
        time_nwfc = list()
        time_wfc = list()
        (r1, c1) = nwfc_list[a]
        (r2, c2) = wfc_list[a]

        for i in range(100):
            start = time.time()
            nwfc.generate(5, row=r1, col=c1)
            end = time.time()
            time_cost = end - start
            time_nwfc.append(time_cost)

            start = time.time()
            board = wfc.BTS(row=r2, col=c2)
            end = time.time()
            time_cost = end - start
            time_wfc.append(time_cost)

        nwfc_mean.append(np.mean(time_nwfc))
        nwfc_std.append(np.std(time_nwfc))
        print('NWFC {}: mean{}, std{}'.format(a, np.mean(time_nwfc), np.std(time_nwfc)))

        wfc_mean.append(np.mean(time_wfc))
        wfc_std.append(np.std(time_wfc))
        print('WFC {}: mean{}, std{}'.format(a, np.mean(time_wfc), np.std(time_wfc)))

    print(wfc_mean)
    print(wfc_std)
    print(nwfc_mean)
    print(nwfc_std)

    plot_experiment_result('Tileset 9-9', (wfc_mean, wfc_std), (nwfc_mean, nwfc_std))
