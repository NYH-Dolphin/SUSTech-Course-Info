import time
import numpy as np
import Tools
from WFC import WFC

EMPTY = -1


class NWFC:
    def __init__(self, DATA_PATH, SAVE_PATH):
        self.data_path = DATA_PATH
        self.save_path = SAVE_PATH
        self.large_board = list()
        self.wfc = None
        self.N = 0
        self.row = 0
        self.col = 0
        self.tracking = 0

    def generate(self, N, row=5, col=8, track=False):
        large_board = [[None for _ in range(col)] for _ in range(row)]
        wfc = WFC(self.data_path, self.save_path, random_seed=1, simple_tiled=True)
        self.wfc = wfc
        self.N = N
        self.row = row
        self.col = col
        for i in range(row):
            for j in range(col):
                conn = np.ones((N, N), type(int)) * EMPTY
                if i > 0:
                    up_board = large_board[i - 1][j]
                    conn[0, :] = up_board[-1, :]
                if j > 0:
                    left_board = large_board[i][j - 1]
                    conn[:, 0] = left_board[:, -1]
                board = wfc.BTS(row=N, col=N, conn=conn, track=track)
                large_board[i][j] = board
        self.large_board = large_board

    def save_diagram(self, name):
        rows = list()
        Tools.create_folder(self.save_path + 'Split/')
        for i in range(len(self.large_board)):
            for j in range(len(self.large_board[i])):
                board = self.large_board[i][j]
                img = self.wfc.get_board_img(board)
                img.save(self.save_path + 'Split/{}-{}.png'.format(i, j))

        for i in range(len(self.large_board)):
            row_matrix = self.large_board[i][0]
            for j in range(1, len(self.large_board[i])):
                row = row_matrix[:, 0:-1]
                row_matrix = np.append(row, self.large_board[i][j], axis=1)
            rows.append(row_matrix)

        board = rows[0]
        for i in range(1, len(rows)):
            col = board[0:-1, :]
            board = np.append(col, rows[i], axis=0)

        diagram = self.wfc.get_board_img(board)
        diagram.save(self.save_path + name + '.png')


if __name__ == '__main__':
    nwfc = NWFC('CCS/SimpleTiled/', 'CCS/NWFCResult/')
    start = time.time()
    nwfc.generate(5, row=50, col=100, track=False)
    end = time.time()
    time_cost = end - start
    print(time_cost)
    nwfc.save_diagram('nwfc-result')
