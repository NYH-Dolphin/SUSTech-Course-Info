from Generator import *
import numpy as np
import pandas as pd
import copy
import random
import time
import os
import Tools
from queue import Queue
from collections import deque

# board message
EMPTY = -1

# heuristic method
RANDOM = 0x1001
MRV = 0x1002
LCV = 0x1003
SEQUENCE = 0x1004
FREQ = 0x1005


class WFC:
    def __init__(self, DATA_PATH, SAVE_PATH, random_seed=922, simple_tiled=False, overlapping=False):
        random.seed(random_seed)
        self.save_path = SAVE_PATH
        Tools.create_folder(self.save_path)

        # overlapping mode
        if overlapping:
            with open(DATA_PATH + 'tile_data.pkl', 'rb') as f2:
                tiles = pickle.load(f2)
                self.tiles = tiles
            state_dict = dict()
            for tile in tiles:
                self.N = tile.im.size[0]
                for dir in range(4):
                    state_dict[(tile.index, dir)] = tile.conn[dir]
            self.state_dict = state_dict

        if simple_tiled:
            data = pd.read_csv(DATA_PATH + 'state_dictionary.csv', header=None)
            state_dict = dict()
            state_num = data.shape[1]
            dir_num = data.shape[0]
            for i in range(state_num):
                for dir in range(dir_num):
                    oppo_dir = dir + 1 if dir % 2 == 0 else dir - 1
                    dir_edge = data.iat[dir, i]
                    conn_state = set()
                    for n in range(state_num):
                        if data.iat[oppo_dir, n] == dir_edge:
                            conn_state.add(n)
                    state_dict[(i, dir)] = conn_state
            self.state_dict = state_dict

            tiles = list(None for _ in range(state_num))
            tile_paths = os.listdir(DATA_PATH)
            for f in tile_paths:
                if f.__contains__('png'):
                    img_path = os.path.join(DATA_PATH, f)
                    img = Image.open(img_path)
                    idx = int(f.replace('.png', ''))
                    tile = Tile(idx, Tools.img2hex(img), img)
                    self.N = tile.img.size[0]
                    tiles[idx] = tile
            self.tiles = tiles

        # record the backtracking times
        self.tracking = 0

    def simple_tiled_sort(self, tile):
        return tile.index

    def save_diagram(self, name=''):
        board = self.save_board
        if board is not None:
            img = self.get_board_img(board)
            img.save(self.save_path + name + '.png')

    def get_board_hex(self, board):
        hex = ''
        for i in range(len(board)):
            for j in range(len(board[i])):
                hex += str(board[i, j])
            hex += '|'
        return hex

    def get_board_img(self, board):
        if board is not None:
            row = len(board)
            col = len(board[0])
            diagram = Image.new('RGB', (col * self.N, row * self.N))
            for i in range(row):
                for j in range(col):
                    img = self.tiles[board[i, j]].img
                    diagram.paste(img, (j * self.N, i * self.N))
            return diagram

    # if back tracking search has a solution, return the board, else return failure(None)
    def BTS(self, row=5, col=10, conn=None, track=True):
        # initial the whole board to be -1, indicates not collapse
        self.board = np.ones((row, col), type(int)) * EMPTY
        self.save_board = None
        self.row = row
        self.col = col

        # initial all the waves
        self.waves = dict()
        for i in range(row):
            for j in range(col):
                self.waves[(i, j)] = {i for i in range(len(self.tiles))}

        start = time.time()
        while True:
            end = time.time()
            if (end - start) * 1000 >= 10:
                return None
            board = self.back_track(copy.deepcopy(self.board), copy.deepcopy(self.waves), conn, track)
            if board is not None:
                self.save_board = board
                return board

    def back_track(self, board, waves, conn, track):

        if conn is not None:
            for i in range(len(conn)):
                for j in range(len(conn[i])):
                    if conn[i, j] != -1:
                        board[i, j] = conn[i, j]
                        waves[(i, j)] = {conn[i, j]}
                        self.AC_3(board, waves, (i, j))

        # not tracking!
        if track is False:
            while True:
                if self.complete(board):
                    return board
                wave_pos = self.observe_wave(board, waves, MRV)
                wave_state = list(waves[wave_pos])
                random.shuffle(wave_state)
                waves[wave_pos] = {wave_state[0]}
                board[wave_pos] = wave_state[0]
                self.AC_3(board, waves, wave_pos)

        stack = deque()
        stack.append((board, waves, ''))
        search_set = set()
        board_set = set()
        while len(stack) != 0:
            (board, waves, search) = stack.pop()
            if self.complete(board):
                return board

            waves_save = copy.deepcopy(waves)
            while True:
                wave_pos = self.observe_wave(board, waves, MRV)
                if wave_pos is None:
                    break
                search1 = search + str(wave_pos) + '-'
                if search1 in search_set:
                    waves.pop(wave_pos)
                else:
                    search_set.add(search)
                    break
            if wave_pos is None:
                continue
            wave_state = list(waves[wave_pos])
            random.shuffle(wave_state)
            for state in wave_state:
                board1 = copy.deepcopy(board)
                board1[wave_pos] = state
                board1_hex = self.get_board_hex(board1)
                if board1_hex not in board_set:
                    board_set.add(board1_hex)
                    waves1 = copy.deepcopy(waves_save)
                    waves1[wave_pos] = {state}
                    if self.AC_3(board1, waves1, wave_pos):
                        stack.append((board1, waves1, search1))
                    else:
                        self.tracking += 1
        return None

    def AC_3(self, board, waves, wave_pos):
        wave = waves[wave_pos]
        queue = Queue()
        edge_dir = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        for n in range(len(edge_dir)):
            vic_pos = tuple(map(sum, zip(wave_pos, edge_dir[n])))
            if vic_pos in waves and board[vic_pos] == EMPTY:
                queue.put((vic_pos, wave, n))
        while queue.qsize() != 0:
            pos, wave, dir = queue.get()  # i, j is the vicinity wave's position
            w_vicinity = waves[pos]  # get vicinity wave
            has_collapse, w_vicinity = self.wave_collapse(w_vicinity, wave, dir)
            waves[pos] = w_vicinity  # set vicinity wave
            if has_collapse:
                if len(w_vicinity) == 0:
                    return False
                if len(w_vicinity) == 1:
                    board[pos] = list(w_vicinity)[0]  # if vicinity wave only remain one state, just collapse it
                for n in range(len(edge_dir)):
                    vic_pos = tuple(map(sum, zip(pos, edge_dir[n])))
                    if vic_pos in waves and board[vic_pos] == EMPTY:
                        queue.put((vic_pos, w_vicinity, n))
        return True

    def wave_collapse(self, w1, w2, dir):
        n = len(w1)  # in the beginning, how many elements inside w1
        w_new = set()
        for s in w2:
            w_new = w_new.union(self.state_dict[(s, dir)])
        w1 = w1.intersection(w_new)
        if n != len(w1):
            return True, w1
        return False, w1

    # return whether all the waves are collapsed
    def complete(self, board):
        return np.sum(board == EMPTY) == 0

    # TODO heuristic part1 - pick one variable
    def observe_wave(self, board, waves, heuristic):
        possible_waves = list()
        for (i, j) in waves:
            if (len(waves[(i, j)]) == 1) and board[i, j] != EMPTY:  # if the wave has collapsed, ignore it
                continue
            possible_waves.append((i, j))
        if len(possible_waves) == 0:
            return None

        # return possible wave in order
        if heuristic == SEQUENCE:
            return possible_waves[0]

        # randomly return one wave
        if heuristic == RANDOM:
            return random.choice(possible_waves)

        # minimum remaining value
        if heuristic == MRV:
            # sort the waves by the remaining possible state values
            sort_waves = sorted(possible_waves, key=lambda x: len(waves[x]))
            if len(sort_waves) == 0:
                print(1)
            minimum_states = len(waves[sort_waves[0]])
            minimum_waves = list()
            for (i, j) in sort_waves:
                if len(waves[(i, j)]) == minimum_states:
                    minimum_waves.append((i, j))
            return random.choice(minimum_waves)

        # least constraint value -> maximum possible edge connection
        if heuristic == LCV:
            wave_connectivity = list()
            for (i, j) in possible_waves:
                conn_sum = 0
                states = waves[(i, j)]
                for state in states:
                    for dir in range(4):
                        conn_sum += len(self.state_dict[(state, dir)])
                wave_connectivity.append((conn_sum, (i, j)))

            sort_wave_connectivity = sorted(wave_connectivity, key=lambda x: -x[0])
            maximum_conn_value = sort_wave_connectivity[0][0]
            maximum_conn = list()
            for conn, wave in sort_wave_connectivity:
                if conn == maximum_conn_value:
                    maximum_conn.append(wave)
                else:
                    break
            return random.choice(maximum_conn)

    # TODO heuristic part2 - pick one state to collapse
    def observe_state(self, waves, wave_pos, heuristic):
        states = list(waves[wave_pos])
        if heuristic == RANDOM:
            random.shuffle(states)
            return states
        return []


if __name__ == '__main__':
    wfc = WFC('SubComplete-4-4/SimpleTiled/', 'SubComplete-4-4/', simple_tiled=True)
    wfc.BTS(row=40, col=30)
