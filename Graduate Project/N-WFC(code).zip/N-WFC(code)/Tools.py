import os
import numpy

# create the folder or delete all the files in the original folder
def create_folder(PATH):
    folder = os.path.exists(PATH)
    if not folder:
        os.makedirs(PATH)
    else:
        del_list = os.listdir(PATH)
        for f in del_list:
            file_path = os.path.join(PATH, f)
            if os.path.isfile(file_path):
                os.remove(file_path)


def rgb2hex(r, g, b):
    return '#{:02x}{:02x}{:02x}'.format(r, g, b)


def get_img_hex_list(img) -> list:
    # image split
    img_rgba = img.convert('RGBA').load()
    width, height = img.size
    img_hex_list = list()
    for i in range(height):
        col_hex = list()
        for j in range(width):
            r, g, b, a = img_rgba[j, i]
            col_hex.append(rgb2hex(r, g, b))
        img_hex_list.append(col_hex)
    return img_hex_list


# convert the image to a hex string
def img2hex(img) -> str:
    img_hex_list = get_img_hex_list(img)
    width, height = img.size
    img_hex_str = '{},{}'.format(width, height)
    for i in range(height):
        for j in range(width):
            img_hex_str += img_hex_list[i][j]
    return img_hex_str


def board2hex(board: numpy.array):
    hex_str = ''
    for i in range(len(board)):
        for j in range(len(board[i])):
            hex_str += str(board[i, j])
        hex_str += '|'
    return hex_str

def edge2hex(edge):
    hex_str = ''
    for i in range(len(edge)):
        hex_str += str(edge[i])
    return hex_str