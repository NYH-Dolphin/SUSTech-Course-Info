import PIL.Image as Image
import Tools
import matplotlib.pyplot as plt
import math
import pickle


class Tile:
    def __init__(self, index, hex, img: Image):
        self.index = index  # index in the tile set
        self.hex = hex  # unique hex identification
        self.img = img  # tile image
        self.inner = [set() for _ in range(4)]  # tile inner edge index [up|down|left|right]
        self.overlap = [set() for _ in range(4)]  # tile overlap edge index [up|down|left|right]
        self.conn = [set() for _ in range(4)]  # tile connection set -> connect to other tile's index


class Edge:
    def __init__(self, index, hex, img):
        self.index = index  # index in the edge set
        self.hex = hex  # unique hex identification
        self.img = img  # edge image


class TileGenerator:
    def __init__(self, IMAGE_PATH, SAVE_PATH):
        """
        :param IMAGE_PATH: The path of input image path (图片路径)
        :param SAVE_PATH: The path of output tile and related information (保存路径)
        """
        self.img = Image.open(IMAGE_PATH)
        self.save_path = SAVE_PATH

    def simpletiled_slice(self, N):
        """
        Simple Tiled Model (Pre-Slice)
        :param N: Slice Kernel
        """
        img = self.img
        width, height = img.size
        folder_path = self.save_path + 'SimpleTiled/'
        Tools.create_folder(folder_path)

        # slice the image
        tile_dict = dict()

        for i in range(0, width - N + 1, N):
            for j in range(0, height - N + 1, N):
                box = (i, j, i + N, j + N)
                tile = img.crop(box)
                tile_dict[Tools.img2hex(tile)] = tile
        index = 0
        for pixel_str in tile_dict:
            pixel = tile_dict[pixel_str]
            pixel.save(folder_path + str(index) + '.png')
            index += 1

        # display slice result
        img_list_plot(list(tile_dict.values()), 'Simple Tiled Model Result').savefig(
            self.save_path + 'SimpleTiled/Simple Tiled Model Result.png', dpi=600)

    def overlapping_slice(self, N):
        '''
        Overlapping Model (Pre-Slice)
        :param N: Slice Kernel
        '''
        img = self.img
        width, height = img.size
        tile_path = self.save_path + 'Overlapping/Tiles/'  # save tile img
        edge_path = self.save_path + 'Overlapping/Edges/'  # save edge img
        data_path = self.save_path + 'Overlapping/Data/'  # save important data
        Tools.create_folder(tile_path)
        Tools.create_folder(edge_path)
        Tools.create_folder(data_path)

        tile_dict = dict()
        edge_dict = dict()

        # record the tile information and overlapping edge information
        for i in range(0, width - N + 1, N):
            for j in range(0, height - N + 1, N):
                box = (i, j, i + N, j + N)
                tile_img = img.crop(box)
                tile_hex = Tools.img2hex(tile_img)
                if tile_hex not in tile_dict:
                    tile = Tile(len(tile_dict), tile_hex, tile_img)
                    tile_dict[tile_hex] = tile
                else:
                    tile = tile_dict[tile_hex]
                # edge direction
                edge_dir = [(i, j, i + N, j + 1), (i, j + N - 1, i + N, j + N),
                            (i, j, i + 1, j + N), (i + N - 1, j, i + N, j + N)]
                # overlapping direction
                overlap_dir = [(i, j - 1, i + N, j), (i, j + N, i + N, j + N + 1),
                               (i - 1, j, i, j + N), (i + N, j, i + N + 1, j + N)]
                # handle the marginal case
                if j == 0:
                    overlap_dir[0] = edge_dir[0]
                if j + N >= height:
                    overlap_dir[1] = edge_dir[1]
                if i == 0:
                    overlap_dir[2] = edge_dir[2]
                if i + N >= width:
                    overlap_dir[3] = edge_dir[3]

                for n in range(4):
                    inner_img = img.crop(edge_dir[n])
                    overlap_img = img.crop(overlap_dir[n])
                    inner_hex = Tools.img2hex(inner_img)
                    overlap_hex = Tools.img2hex(overlap_img)

                    if inner_hex not in edge_dict:
                        edge = Edge(len(edge_dict), inner_hex, inner_img)
                        edge_dict[inner_hex] = edge
                    if overlap_hex not in edge_dict:
                        overlap = Edge(len(edge_dict), overlap_hex, overlap_img)
                        edge_dict[overlap_hex] = overlap
                    tile.inner[n].add(edge_dict[inner_hex])
                    tile.overlap[n].add(edge_dict[overlap_hex])

        # record the overlap & edge information
        index = 0
        info_list = list()
        tiles_value = list(tile_dict.values())
        edge_value = list(edge_dict.values())
        for tile in tiles_value:
            tile.img.save(tile_path + str(index) + '.png')  # save tile img
            info_img = tile_overlapping_info_plot(tile)
            info_list.append(info_img)
            index += 1

        # find the connection information of each tile
        conn_dict = dict()
        for tile in tiles_value:
            for dir in range(4):
                edges = tile.overlap[dir].union(tile.inner[dir])
                for edge in edges:
                    key = (dir, edge.index)
                    if key not in conn_dict:
                        conn_dict[key] = {tile.index}
                    else:
                        conn_dict[key].add(tile.index)
        for tile in tiles_value:
            for dir in range(4):
                oppo_dir = dir + 1 if dir % 2 == 0 else dir - 1
                edges = tile.overlap[dir].union(tile.inner[dir])
                for edge in edges:
                    oppo_key = (oppo_dir, edge.index)
                    if oppo_key in conn_dict:
                        conn_tile = conn_dict[oppo_key]
                        tile.conn[dir] = tile.conn[dir].union(conn_tile)


        # save all the extracted data
        with open(data_path + 'tile_data.pkl', 'wb') as f:
            pickle.dump(tiles_value, f, protocol=pickle.HIGHEST_PROTOCOL)
        with open(data_path + 'edge_data.pkl', 'wb') as f:
            pickle.dump(edge_value, f, protocol=pickle.HIGHEST_PROTOCOL)

        tile_list = [tile.img for tile in tiles_value]
        edge_list = [edge.img for edge in edge_value]
        # save edge img
        index = 0
        for edge_img in edge_list:
            edge_img.save(edge_path + str(index) + '.png')
            index += 1

        # display analysis result
        img_list_plot(tile_list, 'Overlapping Model Result').savefig(
            self.save_path + 'Overlapping/Overlapping Model Result.png',
            dpi=600)
        img_list_plot(edge_list, 'Overlapping Model Edges').savefig(
            self.save_path + 'Overlapping/Overlapping Model Edges.png', dpi=600)
        img_list_plot(info_list, 'Overlapping Model Information').savefig(
            self.save_path + 'Overlapping/Overlapping Model Information.png', dpi=600)


# display a series of images
def img_list_plot(images: list, main_title='', row=0, col=0):
    if row == 0:
        row = 1 + math.floor(len(images) / 8)
    if col == 0:
        if len(images) > 8:
            col = 8
        else:
            col = len(images)

    img = plt.figure(figsize=(col + 1, row + 1), facecolor='#eaeaea', dpi=150)
    img.suptitle(main_title, fontsize=15)
    for index in range(len(images)):
        plt.subplot(row, col, index + 1)
        plt.title(index)
        plt.axis('off')
        plt.imshow(images[index], cmap='gray')
    return img


# display the tile information
def tile_overlapping_info_plot(tile: Tile):
    N = tile.img.size[0]
    col = 0
    for i in range(len(tile.overlap)):
        col = max(col, len(tile.overlap[i]))
    img = Image.new('RGB', (N + col * 4, N + col * 4), color='#eaeaea')
    img.paste(tile.img, (col * 2, col * 2))

    for i in range(len(tile.overlap)):
        edges = list(tile.overlap[i])
        for j in range(len(edges)):
            edge = edges[j]
            pos = [(col * 2, col * 2 - 2 * (j + 1)),
                   (col * 2, col * 2 + N + 2 * (j + 1) - 1),
                   (col * 2 - 2 * (j + 1), col * 2),
                   (col * 2 + N + 2 * (j + 1) - 1, col * 2)]
            img.paste(edge.im, pos[i])
    return img
